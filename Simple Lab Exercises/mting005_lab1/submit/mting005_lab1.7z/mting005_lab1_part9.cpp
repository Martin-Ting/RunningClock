/*
 * mting005_lab1_part9.cpp
 *
 * Created: 7/28/2015 1:59:43 PM
 *  Author: user
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
		
    }
}